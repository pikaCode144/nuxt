const memberCenter_vue_vue_type_style_index_0_scoped_fd46a8e9_lang = ".container[data-v-fd46a8e9]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const memberCenterStyles_2311230d = [memberCenter_vue_vue_type_style_index_0_scoped_fd46a8e9_lang, memberCenter_vue_vue_type_style_index_0_scoped_fd46a8e9_lang];

export { memberCenterStyles_2311230d as default };
//# sourceMappingURL=member-center-styles.2311230d.mjs.map
