import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { ref, computed, shallowRef, watch, provide, createVNode, withDirectives, resolveDirective, mergeProps, Fragment, inject, vShow, nextTick, withCtx, unref, openBlock, createBlock, renderList, toDisplayString, createCommentVNode, createTextVNode, useSSRContext } from 'vue';
import { q as propsFactory, m as makeComponentProps, D as makeTagProps, E as makeThemeProps, k as genericComponent, G as provideTheme, X as useRtl, Y as useLocale, Z as useGroup, $ as VBtn, l as useRender, I as IconValue, a0 as useProxiedModel, a1 as convertToUnit, t as VDefaultsProvider, a2 as VProgressLinear, a3 as makeGroupItemProps, a4 as makeLazyProps, a5 as useGroupItem, a6 as useSsrBoot, a7 as useLazy, a8 as MaybeTransition, a9 as makeVImgProps, i as VImg, _ as _export_sfc, u as useRouter$1, V as VContainer, d as VRow, e as VCol, aa as VResponsive, W as keys } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderStyle, ssrRenderAttr } from 'vue/server-renderer';
import { V as VCard, a as VCardText, b as VCardTitle } from './VCard-909b057c.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';
import 'unctx';
import 'vue-router';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import '@tryghost/content-api';

const _imports_0 = "" + buildAssetsURL("arrow-left.ee709ac2.svg");
const _imports_1 = "" + buildAssetsURL("arrow-right.da21398e.svg");
const handleGesture = (wrapper) => {
  const {
    touchstartX,
    touchendX,
    touchstartY,
    touchendY
  } = wrapper;
  const dirRatio = 0.5;
  const minDistance = 16;
  wrapper.offsetX = touchendX - touchstartX;
  wrapper.offsetY = touchendY - touchstartY;
  if (Math.abs(wrapper.offsetY) < dirRatio * Math.abs(wrapper.offsetX)) {
    wrapper.left && touchendX < touchstartX - minDistance && wrapper.left(wrapper);
    wrapper.right && touchendX > touchstartX + minDistance && wrapper.right(wrapper);
  }
  if (Math.abs(wrapper.offsetX) < dirRatio * Math.abs(wrapper.offsetY)) {
    wrapper.up && touchendY < touchstartY - minDistance && wrapper.up(wrapper);
    wrapper.down && touchendY > touchstartY + minDistance && wrapper.down(wrapper);
  }
};
function touchstart(event, wrapper) {
  var _a;
  const touch = event.changedTouches[0];
  wrapper.touchstartX = touch.clientX;
  wrapper.touchstartY = touch.clientY;
  (_a = wrapper.start) == null ? void 0 : _a.call(wrapper, {
    originalEvent: event,
    ...wrapper
  });
}
function touchend(event, wrapper) {
  var _a;
  const touch = event.changedTouches[0];
  wrapper.touchendX = touch.clientX;
  wrapper.touchendY = touch.clientY;
  (_a = wrapper.end) == null ? void 0 : _a.call(wrapper, {
    originalEvent: event,
    ...wrapper
  });
  handleGesture(wrapper);
}
function touchmove(event, wrapper) {
  var _a;
  const touch = event.changedTouches[0];
  wrapper.touchmoveX = touch.clientX;
  wrapper.touchmoveY = touch.clientY;
  (_a = wrapper.move) == null ? void 0 : _a.call(wrapper, {
    originalEvent: event,
    ...wrapper
  });
}
function createHandlers() {
  let value = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
  const wrapper = {
    touchstartX: 0,
    touchstartY: 0,
    touchendX: 0,
    touchendY: 0,
    touchmoveX: 0,
    touchmoveY: 0,
    offsetX: 0,
    offsetY: 0,
    left: value.left,
    right: value.right,
    up: value.up,
    down: value.down,
    start: value.start,
    move: value.move,
    end: value.end
  };
  return {
    touchstart: (e) => touchstart(e, wrapper),
    touchend: (e) => touchend(e, wrapper),
    touchmove: (e) => touchmove(e, wrapper)
  };
}
function mounted(el, binding) {
  var _a2, _b;
  var _a;
  const value = binding.value;
  const target = (value == null ? void 0 : value.parent) ? el.parentElement : el;
  const options = (_a2 = value == null ? void 0 : value.options) != null ? _a2 : {
    passive: true
  };
  const uid = (_a = binding.instance) == null ? void 0 : _a.$.uid;
  if (!target || !uid)
    return;
  const handlers = createHandlers(binding.value);
  target._touchHandlers = (_b = target._touchHandlers) != null ? _b : /* @__PURE__ */ Object.create(null);
  target._touchHandlers[uid] = handlers;
  keys(handlers).forEach((eventName) => {
    target.addEventListener(eventName, handlers[eventName], options);
  });
}
function unmounted(el, binding) {
  var _a, _b;
  const target = ((_a = binding.value) == null ? void 0 : _a.parent) ? el.parentElement : el;
  const uid = (_b = binding.instance) == null ? void 0 : _b.$.uid;
  if (!(target == null ? void 0 : target._touchHandlers) || !uid)
    return;
  const handlers = target._touchHandlers[uid];
  keys(handlers).forEach((eventName) => {
    target.removeEventListener(eventName, handlers[eventName]);
  });
  delete target._touchHandlers[uid];
}
const Touch = {
  mounted,
  unmounted
};
const Touch$1 = Touch;
const VWindowSymbol = Symbol.for("vuetify:v-window");
const VWindowGroupSymbol = Symbol.for("vuetify:v-window-group");
const makeVWindowProps = propsFactory({
  continuous: Boolean,
  nextIcon: {
    type: [Boolean, String, Function, Object],
    default: "$next"
  },
  prevIcon: {
    type: [Boolean, String, Function, Object],
    default: "$prev"
  },
  reverse: Boolean,
  showArrows: {
    type: [Boolean, String],
    validator: (v) => typeof v === "boolean" || v === "hover"
  },
  touch: {
    type: [Object, Boolean],
    default: void 0
  },
  direction: {
    type: String,
    default: "horizontal"
  },
  modelValue: null,
  disabled: Boolean,
  selectedClass: {
    type: String,
    default: "v-window-item--active"
  },
  // TODO: mandatory should probably not be exposed but do this for now
  mandatory: {
    type: [Boolean, String],
    default: "force"
  },
  ...makeComponentProps(),
  ...makeTagProps(),
  ...makeThemeProps()
}, "VWindow");
const VWindow = genericComponent()({
  name: "VWindow",
  directives: {
    Touch
  },
  props: makeVWindowProps(),
  emits: {
    "update:modelValue": (v) => true
  },
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    const {
      themeClasses
    } = provideTheme(props);
    const {
      isRtl
    } = useRtl();
    const {
      t
    } = useLocale();
    const group = useGroup(props, VWindowGroupSymbol);
    const rootRef = ref();
    const isRtlReverse = computed(() => isRtl.value ? !props.reverse : props.reverse);
    const isReversed = shallowRef(false);
    const transition = computed(() => {
      const axis = props.direction === "vertical" ? "y" : "x";
      const reverse = isRtlReverse.value ? !isReversed.value : isReversed.value;
      const direction = reverse ? "-reverse" : "";
      return `v-window-${axis}${direction}-transition`;
    });
    const transitionCount = shallowRef(0);
    const transitionHeight = ref(void 0);
    const activeIndex = computed(() => {
      return group.items.value.findIndex((item) => group.selected.value.includes(item.id));
    });
    watch(activeIndex, (newVal, oldVal) => {
      const itemsLength = group.items.value.length;
      const lastIndex = itemsLength - 1;
      if (itemsLength <= 2) {
        isReversed.value = newVal < oldVal;
      } else if (newVal === lastIndex && oldVal === 0) {
        isReversed.value = true;
      } else if (newVal === 0 && oldVal === lastIndex) {
        isReversed.value = false;
      } else {
        isReversed.value = newVal < oldVal;
      }
    });
    provide(VWindowSymbol, {
      transition,
      isReversed,
      transitionCount,
      transitionHeight,
      rootRef
    });
    const canMoveBack = computed(() => props.continuous || activeIndex.value !== 0);
    const canMoveForward = computed(() => props.continuous || activeIndex.value !== group.items.value.length - 1);
    function prev() {
      canMoveBack.value && group.prev();
    }
    function next() {
      canMoveForward.value && group.next();
    }
    const arrows = computed(() => {
      const arrows2 = [];
      const prevProps = {
        icon: isRtl.value ? props.nextIcon : props.prevIcon,
        class: `v-window__${isRtlReverse.value ? "right" : "left"}`,
        onClick: group.prev,
        ariaLabel: t("$vuetify.carousel.prev")
      };
      arrows2.push(canMoveBack.value ? slots.prev ? slots.prev({
        props: prevProps
      }) : createVNode(VBtn, prevProps, null) : createVNode("div", null, null));
      const nextProps = {
        icon: isRtl.value ? props.prevIcon : props.nextIcon,
        class: `v-window__${isRtlReverse.value ? "left" : "right"}`,
        onClick: group.next,
        ariaLabel: t("$vuetify.carousel.next")
      };
      arrows2.push(canMoveForward.value ? slots.next ? slots.next({
        props: nextProps
      }) : createVNode(VBtn, nextProps, null) : createVNode("div", null, null));
      return arrows2;
    });
    const touchOptions = computed(() => {
      if (props.touch === false)
        return props.touch;
      const options = {
        left: () => {
          isRtlReverse.value ? prev() : next();
        },
        right: () => {
          isRtlReverse.value ? next() : prev();
        },
        start: (_ref2) => {
          let {
            originalEvent
          } = _ref2;
          originalEvent.stopPropagation();
        }
      };
      return {
        ...options,
        ...props.touch === true ? {} : props.touch
      };
    });
    useRender(() => withDirectives(createVNode(props.tag, {
      "ref": rootRef,
      "class": ["v-window", {
        "v-window--show-arrows-on-hover": props.showArrows === "hover"
      }, themeClasses.value, props.class],
      "style": props.style
    }, {
      default: () => {
        var _a, _b;
        return [createVNode("div", {
          "class": "v-window__container",
          "style": {
            height: transitionHeight.value
          }
        }, [(_a = slots.default) == null ? void 0 : _a.call(slots, {
          group
        }), props.showArrows !== false && createVNode("div", {
          "class": "v-window__controls"
        }, [arrows.value])]), (_b = slots.additional) == null ? void 0 : _b.call(slots, {
          group
        })];
      }
    }), [[resolveDirective("touch"), touchOptions.value]]));
    return {
      group
    };
  }
});
const makeVCarouselProps = propsFactory({
  color: String,
  cycle: Boolean,
  delimiterIcon: {
    type: IconValue,
    default: "$delimiter"
  },
  height: {
    type: [Number, String],
    default: 500
  },
  hideDelimiters: Boolean,
  hideDelimiterBackground: Boolean,
  interval: {
    type: [Number, String],
    default: 6e3,
    validator: (value) => Number(value) > 0
  },
  progress: [Boolean, String],
  verticalDelimiters: [Boolean, String],
  ...makeVWindowProps({
    continuous: true,
    mandatory: "force",
    showArrows: true
  })
}, "VCarousel");
const VCarousel = genericComponent()({
  name: "VCarousel",
  props: makeVCarouselProps(),
  emits: {
    "update:modelValue": (val) => true
  },
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    const model = useProxiedModel(props, "modelValue");
    const {
      t
    } = useLocale();
    const windowRef = ref();
    let slideTimeout = -1;
    watch(model, restartTimeout);
    watch(() => props.interval, restartTimeout);
    watch(() => props.cycle, (val) => {
      if (val)
        restartTimeout();
      else
        window.clearTimeout(slideTimeout);
    });
    function startTimeout() {
      if (!props.cycle || !windowRef.value)
        return;
      slideTimeout = window.setTimeout(windowRef.value.group.next, +props.interval > 0 ? +props.interval : 6e3);
    }
    function restartTimeout() {
      window.clearTimeout(slideTimeout);
      window.requestAnimationFrame(startTimeout);
    }
    useRender(() => {
      const [windowProps] = VWindow.filterProps(props);
      return createVNode(VWindow, mergeProps({
        "ref": windowRef
      }, windowProps, {
        "modelValue": model.value,
        "onUpdate:modelValue": ($event) => model.value = $event,
        "class": ["v-carousel", {
          "v-carousel--hide-delimiter-background": props.hideDelimiterBackground,
          "v-carousel--vertical-delimiters": props.verticalDelimiters
        }, props.class],
        "style": [{
          height: convertToUnit(props.height)
        }, props.style]
      }), {
        default: slots.default,
        additional: (_ref2) => {
          let {
            group
          } = _ref2;
          return createVNode(Fragment, null, [!props.hideDelimiters && createVNode("div", {
            "class": "v-carousel__controls",
            "style": {
              left: props.verticalDelimiters === "left" && props.verticalDelimiters ? 0 : "auto",
              right: props.verticalDelimiters === "right" ? 0 : "auto"
            }
          }, [group.items.value.length > 0 && createVNode(VDefaultsProvider, {
            "defaults": {
              VBtn: {
                color: props.color,
                icon: props.delimiterIcon,
                size: "x-small",
                variant: "text"
              }
            },
            "scoped": true
          }, {
            default: () => [group.items.value.map((item, index2) => {
              const props2 = {
                id: `carousel-item-${item.id}`,
                "aria-label": t("$vuetify.carousel.ariaLabel.delimiter", index2 + 1, group.items.value.length),
                class: [group.isSelected(item.id) && "v-btn--active"],
                onClick: () => group.select(item.id, true)
              };
              return slots.item ? slots.item({
                props: props2,
                item
              }) : createVNode(VBtn, mergeProps(item, props2), null);
            })]
          })]), props.progress && createVNode(VProgressLinear, {
            "class": "v-carousel__progress",
            "color": typeof props.progress === "string" ? props.progress : void 0,
            "modelValue": (group.getItemIndex(model.value) + 1) / group.items.value.length * 100
          }, null)]);
        },
        prev: slots.prev,
        next: slots.next
      });
    });
    return {};
  }
});
const makeVWindowItemProps = propsFactory({
  reverseTransition: {
    type: [Boolean, String],
    default: void 0
  },
  transition: {
    type: [Boolean, String],
    default: void 0
  },
  ...makeComponentProps(),
  ...makeGroupItemProps(),
  ...makeLazyProps()
}, "VWindowItem");
const VWindowItem = genericComponent()({
  name: "VWindowItem",
  directives: {
    Touch: Touch$1
  },
  props: makeVWindowItemProps(),
  emits: {
    "group:selected": (val) => true
  },
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    const window2 = inject(VWindowSymbol);
    const groupItem = useGroupItem(props, VWindowGroupSymbol);
    const {
      isBooted
    } = useSsrBoot();
    if (!window2 || !groupItem)
      throw new Error("[Vuetify] VWindowItem must be used inside VWindow");
    const isTransitioning = shallowRef(false);
    const hasTransition = computed(() => isBooted.value && (window2.isReversed.value ? props.reverseTransition !== false : props.transition !== false));
    function onAfterTransition() {
      if (!isTransitioning.value || !window2) {
        return;
      }
      isTransitioning.value = false;
      if (window2.transitionCount.value > 0) {
        window2.transitionCount.value -= 1;
        if (window2.transitionCount.value === 0) {
          window2.transitionHeight.value = void 0;
        }
      }
    }
    function onBeforeTransition() {
      var _a;
      if (isTransitioning.value || !window2) {
        return;
      }
      isTransitioning.value = true;
      if (window2.transitionCount.value === 0) {
        window2.transitionHeight.value = convertToUnit((_a = window2.rootRef.value) == null ? void 0 : _a.clientHeight);
      }
      window2.transitionCount.value += 1;
    }
    function onTransitionCancelled() {
      onAfterTransition();
    }
    function onEnterTransition(el) {
      if (!isTransitioning.value) {
        return;
      }
      nextTick(() => {
        if (!hasTransition.value || !isTransitioning.value || !window2) {
          return;
        }
        window2.transitionHeight.value = convertToUnit(el.clientHeight);
      });
    }
    const transition = computed(() => {
      const name = window2.isReversed.value ? props.reverseTransition : props.transition;
      return !hasTransition.value ? false : {
        name: typeof name !== "string" ? window2.transition.value : name,
        onBeforeEnter: onBeforeTransition,
        onAfterEnter: onAfterTransition,
        onEnterCancelled: onTransitionCancelled,
        onBeforeLeave: onBeforeTransition,
        onAfterLeave: onAfterTransition,
        onLeaveCancelled: onTransitionCancelled,
        onEnter: onEnterTransition
      };
    });
    const {
      hasContent
    } = useLazy(props, groupItem.isSelected);
    useRender(() => createVNode(MaybeTransition, {
      "transition": transition.value,
      "disabled": !isBooted.value
    }, {
      default: () => {
        var _a;
        return [withDirectives(createVNode("div", {
          "class": ["v-window-item", groupItem.selectedClass.value, props.class],
          "style": props.style
        }, [hasContent.value && ((_a = slots.default) == null ? void 0 : _a.call(slots))]), [[vShow, groupItem.isSelected.value]])];
      }
    }));
    return {
      groupItem
    };
  }
});
const makeVCarouselItemProps = propsFactory({
  ...makeVImgProps(),
  ...makeVWindowItemProps()
}, "VCarouselItem");
const VCarouselItem = genericComponent()({
  name: "VCarouselItem",
  inheritAttrs: false,
  props: makeVCarouselItemProps(),
  setup(props, _ref) {
    let {
      slots,
      attrs
    } = _ref;
    useRender(() => {
      const [imgProps] = VImg.filterProps(props);
      const [windowItemProps] = VWindowItem.filterProps(props);
      return createVNode(VWindowItem, mergeProps({
        "class": "v-carousel-item"
      }, windowItemProps), {
        default: () => [createVNode(VImg, mergeProps(attrs, imgProps), slots)]
      });
    });
  }
});
const _sfc_main$1 = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const carouselRef = ref([]);
    return (_ctx, _push, _parent, _attrs) => {
      if (unref(carouselRef).length) {
        _push(ssrRenderComponent(VCarousel, mergeProps({
          "hide-delimiters": "",
          cycle: "",
          height: "20vw"
        }, _attrs), {
          prev: withCtx(({ props }, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", _imports_0)} style="${ssrRenderStyle({ "cursor": "pointer", "width": "4vw" })}" alt=""${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: _imports_0,
                  onClick: props.onClick,
                  style: { "cursor": "pointer", "width": "4vw" },
                  alt: ""
                }, null, 8, ["onClick"])
              ];
            }
          }),
          next: withCtx(({ props }, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", _imports_1)} style="${ssrRenderStyle({ "cursor": "pointer", "width": "4vw" })}" alt=""${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: _imports_1,
                  onClick: props.onClick,
                  style: { "cursor": "pointer", "width": "4vw" },
                  alt: ""
                }, null, 8, ["onClick"])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<!--[-->`);
              ssrRenderList(unref(carouselRef), (carousel) => {
                _push2(ssrRenderComponent(VCarouselItem, null, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(VImg, { src: carousel }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(VImg, { src: carousel }, null, 8, ["src"])
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
            } else {
              return [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(carouselRef), (carousel) => {
                  return openBlock(), createBlock(VCarouselItem, { key: carousel }, {
                    default: withCtx(() => [
                      createVNode(VImg, { src: carousel }, null, 8, ["src"])
                    ]),
                    _: 2
                  }, 1024);
                }), 128))
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Carousel/index.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Carousel = _sfc_main$1;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter$1();
    const leftRef = ref([]);
    const rightRef = ref([]);
    const threeColRef = ref([]);
    const publicServiceRef = ref([]);
    const toDetail = (id) => router.push({ path: "/detail", query: { id } });
    const toList = (name, tag) => router.push({ path: "/list", query: { title: "\u65B0\u95FB\u4E2D\u5FC3", name, tag } });
    const toPublicService = (info) => {
      let path = "";
      let tag = "";
      switch (info.title) {
        case "\u5F00\u653E\u5B9E\u9A8C\u5BA4\u9884\u7EA6":
          path = "/open-laboratory-reservation";
          tag = "open-laboratory-reservation";
          break;
        case "\u4EEA\u8868\u4EEA\u5668\u5171\u4EAB":
          path = "/shared-instruments-and-equipment";
          tag = "shared-instruments-and-equipment";
          break;
        case "\u6280\u672F\u54A8\u8BE2":
          path = "/technical-consultation";
          tag = "technical-consultation";
          break;
        case "\u653F\u7B56\u54A8\u8BE2":
          path = "/policy-consultation";
          tag = "policy-consultation";
          break;
      }
      router.push({ path, query: { tag } });
    };
    const imgUrl = ref([
      { url: "http://www.srtiu.cn/images/comlogo1.png" },
      { url: "http://www.srtiu.cn/images/comlogo2.png" },
      { url: "http://www.srtiu.cn/images/comlogo3.png" },
      { url: "http://www.srtiu.cn/images/comlogo4.png" },
      { url: "http://www.srtiu.cn/images/comlogo1.png" },
      { url: "http://www.srtiu.cn/images/comlogo2.png" },
      { url: "http://www.srtiu.cn/images/comlogo3.png" },
      { url: "http://www.srtiu.cn/images/comlogo4.png" },
      { url: "http://www.srtiu.cn/images/comlogo1.png" },
      { url: "http://www.srtiu.cn/images/comlogo2.png" },
      { url: "http://www.srtiu.cn/images/comlogo3.png" },
      { url: "http://www.srtiu.cn/images/comlogo4.png" }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home" }, _attrs))} data-v-ceb96daf>`);
      _push(ssrRenderComponent(Carousel, null, null, _parent));
      _push(ssrRenderComponent(VContainer, { style: { "max-width": "1400px" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VRow, {
              justify: "center",
              align: "center"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(VCol, {
                    cols: "4",
                    md: "4"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(VCard, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(VCardText, null, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    if (unref(leftRef).length) {
                                      _push6(`<ul data-v-ceb96daf${_scopeId5}><!--[-->`);
                                      ssrRenderList(unref(leftRef), (left) => {
                                        _push6(`<li data-v-ceb96daf${_scopeId5}><p class="character" data-v-ceb96daf${_scopeId5}>${ssrInterpolate(left.title)}</p></li>`);
                                      });
                                      _push6(`<!--]--></ul>`);
                                    } else {
                                      _push6(`<!---->`);
                                    }
                                  } else {
                                    return [
                                      unref(leftRef).length ? (openBlock(), createBlock("ul", { key: 0 }, [
                                        (openBlock(true), createBlock(Fragment, null, renderList(unref(leftRef), (left) => {
                                          return openBlock(), createBlock("li", {
                                            key: left,
                                            onClick: ($event) => toDetail(left.id)
                                          }, [
                                            createVNode("p", { class: "character" }, toDisplayString(left.title), 1)
                                          ], 8, ["onClick"]);
                                        }), 128))
                                      ])) : createCommentVNode("", true)
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(VCardText, null, {
                                  default: withCtx(() => [
                                    unref(leftRef).length ? (openBlock(), createBlock("ul", { key: 0 }, [
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(leftRef), (left) => {
                                        return openBlock(), createBlock("li", {
                                          key: left,
                                          onClick: ($event) => toDetail(left.id)
                                        }, [
                                          createVNode("p", { class: "character" }, toDisplayString(left.title), 1)
                                        ], 8, ["onClick"]);
                                      }), 128))
                                    ])) : createCommentVNode("", true)
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(VCard, null, {
                            default: withCtx(() => [
                              createVNode(VCardText, null, {
                                default: withCtx(() => [
                                  unref(leftRef).length ? (openBlock(), createBlock("ul", { key: 0 }, [
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(leftRef), (left) => {
                                      return openBlock(), createBlock("li", {
                                        key: left,
                                        onClick: ($event) => toDetail(left.id)
                                      }, [
                                        createVNode("p", { class: "character" }, toDisplayString(left.title), 1)
                                      ], 8, ["onClick"]);
                                    }), 128))
                                  ])) : createCommentVNode("", true)
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(VCol, {
                    cols: "4",
                    md: "4"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(VCard, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(VCardText, null, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<div class="center-top" data-v-ceb96daf${_scopeId5}>\u89E3\u7801\u5B9E\u9A8C\u5BA4</div>`);
                                    _push6(ssrRenderComponent(VResponsive, null, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`<video controls style="${ssrRenderStyle({ "width": "100%", "height": "100%" })}" data-v-ceb96daf${_scopeId6}><source src="http://cloud.video.taobao.com/play/u/3459968589/p/1/e/6/t/1/50046750855.mp4" type="video/mp4" data-v-ceb96daf${_scopeId6}></video>`);
                                        } else {
                                          return [
                                            createVNode("video", {
                                              controls: "",
                                              style: { "width": "100%", "height": "100%" }
                                            }, [
                                              createVNode("source", {
                                                src: "http://cloud.video.taobao.com/play/u/3459968589/p/1/e/6/t/1/50046750855.mp4",
                                                type: "video/mp4"
                                              })
                                            ])
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode("div", { class: "center-top" }, "\u89E3\u7801\u5B9E\u9A8C\u5BA4"),
                                      createVNode(VResponsive, null, {
                                        default: withCtx(() => [
                                          createVNode("video", {
                                            controls: "",
                                            style: { "width": "100%", "height": "100%" }
                                          }, [
                                            createVNode("source", {
                                              src: "http://cloud.video.taobao.com/play/u/3459968589/p/1/e/6/t/1/50046750855.mp4",
                                              type: "video/mp4"
                                            })
                                          ])
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(VCardText, null, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "center-top" }, "\u89E3\u7801\u5B9E\u9A8C\u5BA4"),
                                    createVNode(VResponsive, null, {
                                      default: withCtx(() => [
                                        createVNode("video", {
                                          controls: "",
                                          style: { "width": "100%", "height": "100%" }
                                        }, [
                                          createVNode("source", {
                                            src: "http://cloud.video.taobao.com/play/u/3459968589/p/1/e/6/t/1/50046750855.mp4",
                                            type: "video/mp4"
                                          })
                                        ])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(VCard, null, {
                            default: withCtx(() => [
                              createVNode(VCardText, null, {
                                default: withCtx(() => [
                                  createVNode("div", { class: "center-top" }, "\u89E3\u7801\u5B9E\u9A8C\u5BA4"),
                                  createVNode(VResponsive, null, {
                                    default: withCtx(() => [
                                      createVNode("video", {
                                        controls: "",
                                        style: { "width": "100%", "height": "100%" }
                                      }, [
                                        createVNode("source", {
                                          src: "http://cloud.video.taobao.com/play/u/3459968589/p/1/e/6/t/1/50046750855.mp4",
                                          type: "video/mp4"
                                        })
                                      ])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(VCol, {
                    cols: "4",
                    md: "4"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(VCard, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(VCardText, null, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    if (unref(rightRef).length) {
                                      _push6(`<ul data-v-ceb96daf${_scopeId5}><!--[-->`);
                                      ssrRenderList(unref(rightRef), (right) => {
                                        _push6(`<li data-v-ceb96daf${_scopeId5}><p class="character" data-v-ceb96daf${_scopeId5}>${ssrInterpolate(right.title)}</p></li>`);
                                      });
                                      _push6(`<!--]--></ul>`);
                                    } else {
                                      _push6(`<!---->`);
                                    }
                                  } else {
                                    return [
                                      unref(rightRef).length ? (openBlock(), createBlock("ul", { key: 0 }, [
                                        (openBlock(true), createBlock(Fragment, null, renderList(unref(rightRef), (right) => {
                                          return openBlock(), createBlock("li", {
                                            key: right,
                                            onClick: ($event) => toDetail(right.id)
                                          }, [
                                            createVNode("p", { class: "character" }, toDisplayString(right.title), 1)
                                          ], 8, ["onClick"]);
                                        }), 128))
                                      ])) : createCommentVNode("", true)
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(VCardText, null, {
                                  default: withCtx(() => [
                                    unref(rightRef).length ? (openBlock(), createBlock("ul", { key: 0 }, [
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(rightRef), (right) => {
                                        return openBlock(), createBlock("li", {
                                          key: right,
                                          onClick: ($event) => toDetail(right.id)
                                        }, [
                                          createVNode("p", { class: "character" }, toDisplayString(right.title), 1)
                                        ], 8, ["onClick"]);
                                      }), 128))
                                    ])) : createCommentVNode("", true)
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(VCard, null, {
                            default: withCtx(() => [
                              createVNode(VCardText, null, {
                                default: withCtx(() => [
                                  unref(rightRef).length ? (openBlock(), createBlock("ul", { key: 0 }, [
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(rightRef), (right) => {
                                      return openBlock(), createBlock("li", {
                                        key: right,
                                        onClick: ($event) => toDetail(right.id)
                                      }, [
                                        createVNode("p", { class: "character" }, toDisplayString(right.title), 1)
                                      ], 8, ["onClick"]);
                                    }), 128))
                                  ])) : createCommentVNode("", true)
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(VCol, {
                      cols: "4",
                      md: "4"
                    }, {
                      default: withCtx(() => [
                        createVNode(VCard, null, {
                          default: withCtx(() => [
                            createVNode(VCardText, null, {
                              default: withCtx(() => [
                                unref(leftRef).length ? (openBlock(), createBlock("ul", { key: 0 }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(unref(leftRef), (left) => {
                                    return openBlock(), createBlock("li", {
                                      key: left,
                                      onClick: ($event) => toDetail(left.id)
                                    }, [
                                      createVNode("p", { class: "character" }, toDisplayString(left.title), 1)
                                    ], 8, ["onClick"]);
                                  }), 128))
                                ])) : createCommentVNode("", true)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(VCol, {
                      cols: "4",
                      md: "4"
                    }, {
                      default: withCtx(() => [
                        createVNode(VCard, null, {
                          default: withCtx(() => [
                            createVNode(VCardText, null, {
                              default: withCtx(() => [
                                createVNode("div", { class: "center-top" }, "\u89E3\u7801\u5B9E\u9A8C\u5BA4"),
                                createVNode(VResponsive, null, {
                                  default: withCtx(() => [
                                    createVNode("video", {
                                      controls: "",
                                      style: { "width": "100%", "height": "100%" }
                                    }, [
                                      createVNode("source", {
                                        src: "http://cloud.video.taobao.com/play/u/3459968589/p/1/e/6/t/1/50046750855.mp4",
                                        type: "video/mp4"
                                      })
                                    ])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(VCol, {
                      cols: "4",
                      md: "4"
                    }, {
                      default: withCtx(() => [
                        createVNode(VCard, null, {
                          default: withCtx(() => [
                            createVNode(VCardText, null, {
                              default: withCtx(() => [
                                unref(rightRef).length ? (openBlock(), createBlock("ul", { key: 0 }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(unref(rightRef), (right) => {
                                    return openBlock(), createBlock("li", {
                                      key: right,
                                      onClick: ($event) => toDetail(right.id)
                                    }, [
                                      createVNode("p", { class: "character" }, toDisplayString(right.title), 1)
                                    ], 8, ["onClick"]);
                                  }), 128))
                                ])) : createCommentVNode("", true)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            if (unref(threeColRef).length) {
              _push2(ssrRenderComponent(VRow, null, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<!--[-->`);
                    ssrRenderList(unref(threeColRef), (item, index2) => {
                      _push3(ssrRenderComponent(VCol, {
                        cols: "12",
                        md: "4"
                      }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`<div class="container" style="${ssrRenderStyle({ "display": "flex", "justify-content": "space-evenly" })}" data-v-ceb96daf${_scopeId3}><span class="left" data-v-ceb96daf${_scopeId3}>${ssrInterpolate(item[0])}</span><span class="center" data-v-ceb96daf${_scopeId3}>${ssrInterpolate(item[2])}</span><span class="right" data-v-ceb96daf${_scopeId3}>\u67E5\u770B\u66F4\u591A&gt;</span></div>`);
                          } else {
                            return [
                              createVNode("div", {
                                class: "container",
                                style: { "display": "flex", "justify-content": "space-evenly" }
                              }, [
                                createVNode("span", { class: "left" }, toDisplayString(item[0]), 1),
                                createVNode("span", { class: "center" }, toDisplayString(item[2]), 1),
                                createVNode("span", {
                                  class: "right",
                                  onClick: ($event) => toList(item[0], item[1])
                                }, "\u67E5\u770B\u66F4\u591A>", 8, ["onClick"])
                              ])
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                    });
                    _push3(`<!--]-->`);
                  } else {
                    return [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(threeColRef), (item, index2) => {
                        return openBlock(), createBlock(VCol, {
                          key: item[0],
                          cols: "12",
                          md: "4"
                        }, {
                          default: withCtx(() => [
                            createVNode("div", {
                              class: "container",
                              style: { "display": "flex", "justify-content": "space-evenly" }
                            }, [
                              createVNode("span", { class: "left" }, toDisplayString(item[0]), 1),
                              createVNode("span", { class: "center" }, toDisplayString(item[2]), 1),
                              createVNode("span", {
                                class: "right",
                                onClick: ($event) => toList(item[0], item[1])
                              }, "\u67E5\u770B\u66F4\u591A>", 8, ["onClick"])
                            ])
                          ]),
                          _: 2
                        }, 1024);
                      }), 128))
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(VRow, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(VCol, {
                    cols: "12",
                    class: "subTitle"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="circle3" data-v-ceb96daf${_scopeId3}></div><div class="circle2" data-v-ceb96daf${_scopeId3}></div><div class="circle1" data-v-ceb96daf${_scopeId3}></div><div data-v-ceb96daf${_scopeId3}>\u516C\u5171\u670D\u52A1</div><div class="circle1" data-v-ceb96daf${_scopeId3}></div><div class="circle2" data-v-ceb96daf${_scopeId3}></div><div class="circle3" data-v-ceb96daf${_scopeId3}></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "circle3" }),
                          createVNode("div", { class: "circle2" }),
                          createVNode("div", { class: "circle1" }),
                          createVNode("div", null, "\u516C\u5171\u670D\u52A1"),
                          createVNode("div", { class: "circle1" }),
                          createVNode("div", { class: "circle2" }),
                          createVNode("div", { class: "circle3" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(VCol, {
                      cols: "12",
                      class: "subTitle"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "circle3" }),
                        createVNode("div", { class: "circle2" }),
                        createVNode("div", { class: "circle1" }),
                        createVNode("div", null, "\u516C\u5171\u670D\u52A1"),
                        createVNode("div", { class: "circle1" }),
                        createVNode("div", { class: "circle2" }),
                        createVNode("div", { class: "circle3" })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(VRow, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(unref(publicServiceRef), (item) => {
                    _push3(ssrRenderComponent(VCol, {
                      cols: "12",
                      md: "3",
                      key: item
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(VCard, { class: "boxInfo" }, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(VCardTitle, { class: "title" }, {
                                  default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(`${ssrInterpolate(item.title)}`);
                                    } else {
                                      return [
                                        createTextVNode(toDisplayString(item.title), 1)
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                                _push5(ssrRenderComponent(VCardText, { class: "info" }, null, _parent5, _scopeId4));
                                _push5(ssrRenderComponent(VBtn, {
                                  class: "btn",
                                  color: "medium-emphasis",
                                  "min-width": "92",
                                  rounded: "",
                                  variant: "outlined",
                                  onClick: ($event) => toPublicService(item)
                                }, {
                                  default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(` \u67E5\u770B\u8BE6\u60C5 `);
                                    } else {
                                      return [
                                        createTextVNode(" \u67E5\u770B\u8BE6\u60C5 ")
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(VCardTitle, { class: "title" }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(item.title), 1)
                                    ]),
                                    _: 2
                                  }, 1024),
                                  createVNode(VCardText, {
                                    class: "info",
                                    innerHTML: item.html
                                  }, null, 8, ["innerHTML"]),
                                  createVNode(VBtn, {
                                    class: "btn",
                                    color: "medium-emphasis",
                                    "min-width": "92",
                                    rounded: "",
                                    variant: "outlined",
                                    onClick: ($event) => toPublicService(item)
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" \u67E5\u770B\u8BE6\u60C5 ")
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(VCard, { class: "boxInfo" }, {
                              default: withCtx(() => [
                                createVNode(VCardTitle, { class: "title" }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(item.title), 1)
                                  ]),
                                  _: 2
                                }, 1024),
                                createVNode(VCardText, {
                                  class: "info",
                                  innerHTML: item.html
                                }, null, 8, ["innerHTML"]),
                                createVNode(VBtn, {
                                  class: "btn",
                                  color: "medium-emphasis",
                                  "min-width": "92",
                                  rounded: "",
                                  variant: "outlined",
                                  onClick: ($event) => toPublicService(item)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" \u67E5\u770B\u8BE6\u60C5 ")
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"])
                              ]),
                              _: 2
                            }, 1024)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(publicServiceRef), (item) => {
                      return openBlock(), createBlock(VCol, {
                        cols: "12",
                        md: "3",
                        key: item
                      }, {
                        default: withCtx(() => [
                          createVNode(VCard, { class: "boxInfo" }, {
                            default: withCtx(() => [
                              createVNode(VCardTitle, { class: "title" }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(item.title), 1)
                                ]),
                                _: 2
                              }, 1024),
                              createVNode(VCardText, {
                                class: "info",
                                innerHTML: item.html
                              }, null, 8, ["innerHTML"]),
                              createVNode(VBtn, {
                                class: "btn",
                                color: "medium-emphasis",
                                "min-width": "92",
                                rounded: "",
                                variant: "outlined",
                                onClick: ($event) => toPublicService(item)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" \u67E5\u770B\u8BE6\u60C5 ")
                                ]),
                                _: 2
                              }, 1032, ["onClick"])
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1024);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(VRow, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(VCol, {
                    cols: "12",
                    class: "subTitle"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="circle3" data-v-ceb96daf${_scopeId3}></div><div class="circle2" data-v-ceb96daf${_scopeId3}></div><div class="circle1" data-v-ceb96daf${_scopeId3}></div><div data-v-ceb96daf${_scopeId3}>\u8054\u76DF\u670D\u52A1</div><div class="circle1" data-v-ceb96daf${_scopeId3}></div><div class="circle2" data-v-ceb96daf${_scopeId3}></div><div class="circle3" data-v-ceb96daf${_scopeId3}></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "circle3" }),
                          createVNode("div", { class: "circle2" }),
                          createVNode("div", { class: "circle1" }),
                          createVNode("div", null, "\u8054\u76DF\u670D\u52A1"),
                          createVNode("div", { class: "circle1" }),
                          createVNode("div", { class: "circle2" }),
                          createVNode("div", { class: "circle3" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(VCol, {
                      cols: "12",
                      class: "subTitle"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "circle3" }),
                        createVNode("div", { class: "circle2" }),
                        createVNode("div", { class: "circle1" }),
                        createVNode("div", null, "\u8054\u76DF\u670D\u52A1"),
                        createVNode("div", { class: "circle1" }),
                        createVNode("div", { class: "circle2" }),
                        createVNode("div", { class: "circle3" })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(VRow, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(unref(imgUrl), (item) => {
                    _push3(ssrRenderComponent(VCol, {
                      cols: "12",
                      md: "3",
                      key: item
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(VCard, { class: "imgBox" }, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(`<img${ssrRenderAttr("src", item.url)} alt="" data-v-ceb96daf${_scopeId4}>`);
                              } else {
                                return [
                                  createVNode("img", {
                                    src: item.url,
                                    alt: ""
                                  }, null, 8, ["src"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(VCard, { class: "imgBox" }, {
                              default: withCtx(() => [
                                createVNode("img", {
                                  src: item.url,
                                  alt: ""
                                }, null, 8, ["src"])
                              ]),
                              _: 2
                            }, 1024)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(imgUrl), (item) => {
                      return openBlock(), createBlock(VCol, {
                        cols: "12",
                        md: "3",
                        key: item
                      }, {
                        default: withCtx(() => [
                          createVNode(VCard, { class: "imgBox" }, {
                            default: withCtx(() => [
                              createVNode("img", {
                                src: item.url,
                                alt: ""
                              }, null, 8, ["src"])
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1024);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VRow, {
                justify: "center",
                align: "center"
              }, {
                default: withCtx(() => [
                  createVNode(VCol, {
                    cols: "4",
                    md: "4"
                  }, {
                    default: withCtx(() => [
                      createVNode(VCard, null, {
                        default: withCtx(() => [
                          createVNode(VCardText, null, {
                            default: withCtx(() => [
                              unref(leftRef).length ? (openBlock(), createBlock("ul", { key: 0 }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(unref(leftRef), (left) => {
                                  return openBlock(), createBlock("li", {
                                    key: left,
                                    onClick: ($event) => toDetail(left.id)
                                  }, [
                                    createVNode("p", { class: "character" }, toDisplayString(left.title), 1)
                                  ], 8, ["onClick"]);
                                }), 128))
                              ])) : createCommentVNode("", true)
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(VCol, {
                    cols: "4",
                    md: "4"
                  }, {
                    default: withCtx(() => [
                      createVNode(VCard, null, {
                        default: withCtx(() => [
                          createVNode(VCardText, null, {
                            default: withCtx(() => [
                              createVNode("div", { class: "center-top" }, "\u89E3\u7801\u5B9E\u9A8C\u5BA4"),
                              createVNode(VResponsive, null, {
                                default: withCtx(() => [
                                  createVNode("video", {
                                    controls: "",
                                    style: { "width": "100%", "height": "100%" }
                                  }, [
                                    createVNode("source", {
                                      src: "http://cloud.video.taobao.com/play/u/3459968589/p/1/e/6/t/1/50046750855.mp4",
                                      type: "video/mp4"
                                    })
                                  ])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(VCol, {
                    cols: "4",
                    md: "4"
                  }, {
                    default: withCtx(() => [
                      createVNode(VCard, null, {
                        default: withCtx(() => [
                          createVNode(VCardText, null, {
                            default: withCtx(() => [
                              unref(rightRef).length ? (openBlock(), createBlock("ul", { key: 0 }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(unref(rightRef), (right) => {
                                  return openBlock(), createBlock("li", {
                                    key: right,
                                    onClick: ($event) => toDetail(right.id)
                                  }, [
                                    createVNode("p", { class: "character" }, toDisplayString(right.title), 1)
                                  ], 8, ["onClick"]);
                                }), 128))
                              ])) : createCommentVNode("", true)
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              unref(threeColRef).length ? (openBlock(), createBlock(VRow, { key: 0 }, {
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(threeColRef), (item, index2) => {
                    return openBlock(), createBlock(VCol, {
                      key: item[0],
                      cols: "12",
                      md: "4"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "container",
                          style: { "display": "flex", "justify-content": "space-evenly" }
                        }, [
                          createVNode("span", { class: "left" }, toDisplayString(item[0]), 1),
                          createVNode("span", { class: "center" }, toDisplayString(item[2]), 1),
                          createVNode("span", {
                            class: "right",
                            onClick: ($event) => toList(item[0], item[1])
                          }, "\u67E5\u770B\u66F4\u591A>", 8, ["onClick"])
                        ])
                      ]),
                      _: 2
                    }, 1024);
                  }), 128))
                ]),
                _: 1
              })) : createCommentVNode("", true),
              createVNode(VRow, null, {
                default: withCtx(() => [
                  createVNode(VCol, {
                    cols: "12",
                    class: "subTitle"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "circle3" }),
                      createVNode("div", { class: "circle2" }),
                      createVNode("div", { class: "circle1" }),
                      createVNode("div", null, "\u516C\u5171\u670D\u52A1"),
                      createVNode("div", { class: "circle1" }),
                      createVNode("div", { class: "circle2" }),
                      createVNode("div", { class: "circle3" })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(VRow, null, {
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(publicServiceRef), (item) => {
                    return openBlock(), createBlock(VCol, {
                      cols: "12",
                      md: "3",
                      key: item
                    }, {
                      default: withCtx(() => [
                        createVNode(VCard, { class: "boxInfo" }, {
                          default: withCtx(() => [
                            createVNode(VCardTitle, { class: "title" }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(item.title), 1)
                              ]),
                              _: 2
                            }, 1024),
                            createVNode(VCardText, {
                              class: "info",
                              innerHTML: item.html
                            }, null, 8, ["innerHTML"]),
                            createVNode(VBtn, {
                              class: "btn",
                              color: "medium-emphasis",
                              "min-width": "92",
                              rounded: "",
                              variant: "outlined",
                              onClick: ($event) => toPublicService(item)
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" \u67E5\u770B\u8BE6\u60C5 ")
                              ]),
                              _: 2
                            }, 1032, ["onClick"])
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1024);
                  }), 128))
                ]),
                _: 1
              }),
              createVNode(VRow, null, {
                default: withCtx(() => [
                  createVNode(VCol, {
                    cols: "12",
                    class: "subTitle"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "circle3" }),
                      createVNode("div", { class: "circle2" }),
                      createVNode("div", { class: "circle1" }),
                      createVNode("div", null, "\u8054\u76DF\u670D\u52A1"),
                      createVNode("div", { class: "circle1" }),
                      createVNode("div", { class: "circle2" }),
                      createVNode("div", { class: "circle3" })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(VRow, null, {
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(imgUrl), (item) => {
                    return openBlock(), createBlock(VCol, {
                      cols: "12",
                      md: "3",
                      key: item
                    }, {
                      default: withCtx(() => [
                        createVNode(VCard, { class: "imgBox" }, {
                          default: withCtx(() => [
                            createVNode("img", {
                              src: item.url,
                              alt: ""
                            }, null, 8, ["src"])
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1024);
                  }), 128))
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-ceb96daf"]]);

export { index as default };
//# sourceMappingURL=index-ed203c3c.mjs.map
