const allianceIntroduction_vue_vue_type_style_index_0_scoped_1d4e83fa_lang = ".container[data-v-1d4e83fa]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const allianceIntroductionStyles_72471179 = [allianceIntroduction_vue_vue_type_style_index_0_scoped_1d4e83fa_lang, allianceIntroduction_vue_vue_type_style_index_0_scoped_1d4e83fa_lang];

export { allianceIntroductionStyles_72471179 as default };
//# sourceMappingURL=alliance-introduction-styles.72471179.mjs.map
