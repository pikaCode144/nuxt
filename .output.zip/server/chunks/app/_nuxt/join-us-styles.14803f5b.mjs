const joinUs_vue_vue_type_style_index_0_scoped_c4b70829_lang = ".container[data-v-c4b70829]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const joinUsStyles_14803f5b = [joinUs_vue_vue_type_style_index_0_scoped_c4b70829_lang, joinUs_vue_vue_type_style_index_0_scoped_c4b70829_lang];

export { joinUsStyles_14803f5b as default };
//# sourceMappingURL=join-us-styles.14803f5b.mjs.map
