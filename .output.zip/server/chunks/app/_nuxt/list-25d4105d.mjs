import { ref, withAsyncContext, unref, withCtx, openBlock, createBlock, Fragment, renderList, createVNode, toDisplayString, createCommentVNode, useSSRContext } from 'vue';
import { _ as _export_sfc, u as useRouter$1, b as useRoute, f as fetchGhostPosts, V as VContainer, e as VRow, g as VCol, h as VSheet, i as VList, j as VListItem } from '../server.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import { _ as _sfc_main$1 } from './index-1aae9bf6.mjs';
import { f as formatDate } from './format-7fadbdd9.mjs';
import { V as VCard } from './VCard-428ef368.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'h3';
import 'ufo';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'defu';
import 'ohash';
import '@tryghost/content-api';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';
import 'dayjs';

const _sfc_main = {
  __name: "list",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const router = useRouter$1();
    const route = useRoute();
    const { title, name, tag } = route.query;
    const nameRef = ref(name);
    const asideDataRef = ref([]);
    const listDataRef = ref([]);
    const [navBars, posts] = ([__temp, __restore] = withAsyncContext(() => Promise.all([
      fetchGhostPosts("nav-bars"),
      fetchGhostPosts(tag)
    ])), __temp = await __temp, __restore(), __temp);
    asideDataRef.value = navBars.data.value.posts.map((item) => item.title.split("/")).filter((item) => item.includes(title))[0].map((str) => str.split("+"));
    listDataRef.value = posts.data.value.posts;
    const toDetail = (id) => {
      router.push({ path: "/detail", query: { id } });
    };
    const changeName = async (info) => {
      nameRef.value = info[0];
      const pages = await fetchGhostPosts(info[1]);
      listDataRef.value = pages.data.value.posts;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(_sfc_main$1), null, null, _parent));
      _push(ssrRenderComponent(VContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VRow, { "no-gutters": "" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(VCol, { cols: "3" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(VSheet, { class: "pa-2 ma-2" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              if (unref(asideDataRef).length) {
                                _push5(ssrRenderComponent(VCard, { class: "mx-auto card" }, {
                                  default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(`<div class="title" data-v-d91279ff${_scopeId5}><span class="subtitle" data-v-d91279ff${_scopeId5}>${ssrInterpolate(unref(asideDataRef)[0][0])}</span><span class="circle1" data-v-d91279ff${_scopeId5}></span><span class="circle2" data-v-d91279ff${_scopeId5}></span><span class="circle2" data-v-d91279ff${_scopeId5}></span></div>`);
                                      _push6(ssrRenderComponent(VList, {
                                        class: "item",
                                        color: "#152f86"
                                      }, {
                                        default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(`<!--[-->`);
                                            ssrRenderList(unref(asideDataRef).slice(1), (list2) => {
                                              _push7(ssrRenderComponent(VListItem, {
                                                active: unref(nameRef) === list2[0],
                                                title: list2[0],
                                                onClick: ($event) => changeName(list2)
                                              }, null, _parent7, _scopeId6));
                                            });
                                            _push7(`<!--]-->`);
                                          } else {
                                            return [
                                              (openBlock(true), createBlock(Fragment, null, renderList(unref(asideDataRef).slice(1), (list2) => {
                                                return openBlock(), createBlock(VListItem, {
                                                  key: list2[1],
                                                  active: unref(nameRef) === list2[0],
                                                  title: list2[0],
                                                  onClick: ($event) => changeName(list2)
                                                }, null, 8, ["active", "title", "onClick"]);
                                              }), 128))
                                            ];
                                          }
                                        }),
                                        _: 1
                                      }, _parent6, _scopeId5));
                                    } else {
                                      return [
                                        createVNode("div", { class: "title" }, [
                                          createVNode("span", { class: "subtitle" }, toDisplayString(unref(asideDataRef)[0][0]), 1),
                                          createVNode("span", { class: "circle1" }),
                                          createVNode("span", { class: "circle2" }),
                                          createVNode("span", { class: "circle2" })
                                        ]),
                                        createVNode(VList, {
                                          class: "item",
                                          color: "#152f86"
                                        }, {
                                          default: withCtx(() => [
                                            (openBlock(true), createBlock(Fragment, null, renderList(unref(asideDataRef).slice(1), (list2) => {
                                              return openBlock(), createBlock(VListItem, {
                                                key: list2[1],
                                                active: unref(nameRef) === list2[0],
                                                title: list2[0],
                                                onClick: ($event) => changeName(list2)
                                              }, null, 8, ["active", "title", "onClick"]);
                                            }), 128))
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent5, _scopeId4));
                              } else {
                                _push5(`<!---->`);
                              }
                            } else {
                              return [
                                unref(asideDataRef).length ? (openBlock(), createBlock(VCard, {
                                  key: 0,
                                  class: "mx-auto card"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "title" }, [
                                      createVNode("span", { class: "subtitle" }, toDisplayString(unref(asideDataRef)[0][0]), 1),
                                      createVNode("span", { class: "circle1" }),
                                      createVNode("span", { class: "circle2" }),
                                      createVNode("span", { class: "circle2" })
                                    ]),
                                    createVNode(VList, {
                                      class: "item",
                                      color: "#152f86"
                                    }, {
                                      default: withCtx(() => [
                                        (openBlock(true), createBlock(Fragment, null, renderList(unref(asideDataRef).slice(1), (list2) => {
                                          return openBlock(), createBlock(VListItem, {
                                            key: list2[1],
                                            active: unref(nameRef) === list2[0],
                                            title: list2[0],
                                            onClick: ($event) => changeName(list2)
                                          }, null, 8, ["active", "title", "onClick"]);
                                        }), 128))
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })) : createCommentVNode("", true)
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(VSheet, { class: "pa-2 ma-2" }, {
                            default: withCtx(() => [
                              unref(asideDataRef).length ? (openBlock(), createBlock(VCard, {
                                key: 0,
                                class: "mx-auto card"
                              }, {
                                default: withCtx(() => [
                                  createVNode("div", { class: "title" }, [
                                    createVNode("span", { class: "subtitle" }, toDisplayString(unref(asideDataRef)[0][0]), 1),
                                    createVNode("span", { class: "circle1" }),
                                    createVNode("span", { class: "circle2" }),
                                    createVNode("span", { class: "circle2" })
                                  ]),
                                  createVNode(VList, {
                                    class: "item",
                                    color: "#152f86"
                                  }, {
                                    default: withCtx(() => [
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(asideDataRef).slice(1), (list2) => {
                                        return openBlock(), createBlock(VListItem, {
                                          key: list2[1],
                                          active: unref(nameRef) === list2[0],
                                          title: list2[0],
                                          onClick: ($event) => changeName(list2)
                                        }, null, 8, ["active", "title", "onClick"]);
                                      }), 128))
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })) : createCommentVNode("", true)
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(VCol, { cols: "9" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(VSheet, { class: "pa-2 ma-2" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<div class="title1" data-v-d91279ff${_scopeId4}><div class="subtitle1" data-v-d91279ff${_scopeId4}>${ssrInterpolate(unref(nameRef))}</div><div class="vertical-line" data-v-d91279ff${_scopeId4}></div></div><!--[-->`);
                              ssrRenderList(unref(listDataRef), (item) => {
                                _push5(`<div class="list" data-v-d91279ff${_scopeId4}><div class="left" data-v-d91279ff${_scopeId4}>${ssrInterpolate(unref(formatDate)(item.created_at))}</div><div class="right" data-v-d91279ff${_scopeId4}>${ssrInterpolate(item.title)}</div></div>`);
                              });
                              _push5(`<!--]-->`);
                            } else {
                              return [
                                createVNode("div", { class: "title1" }, [
                                  createVNode("div", { class: "subtitle1" }, toDisplayString(unref(nameRef)), 1),
                                  createVNode("div", { class: "vertical-line" })
                                ]),
                                (openBlock(true), createBlock(Fragment, null, renderList(unref(listDataRef), (item) => {
                                  return openBlock(), createBlock("div", {
                                    class: "list",
                                    onClick: ($event) => toDetail(item.id)
                                  }, [
                                    createVNode("div", { class: "left" }, toDisplayString(unref(formatDate)(item.created_at)), 1),
                                    createVNode("div", { class: "right" }, toDisplayString(item.title), 1)
                                  ], 8, ["onClick"]);
                                }), 256))
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(VSheet, { class: "pa-2 ma-2" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "title1" }, [
                                createVNode("div", { class: "subtitle1" }, toDisplayString(unref(nameRef)), 1),
                                createVNode("div", { class: "vertical-line" })
                              ]),
                              (openBlock(true), createBlock(Fragment, null, renderList(unref(listDataRef), (item) => {
                                return openBlock(), createBlock("div", {
                                  class: "list",
                                  onClick: ($event) => toDetail(item.id)
                                }, [
                                  createVNode("div", { class: "left" }, toDisplayString(unref(formatDate)(item.created_at)), 1),
                                  createVNode("div", { class: "right" }, toDisplayString(item.title), 1)
                                ], 8, ["onClick"]);
                              }), 256))
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(VCol, { cols: "3" }, {
                      default: withCtx(() => [
                        createVNode(VSheet, { class: "pa-2 ma-2" }, {
                          default: withCtx(() => [
                            unref(asideDataRef).length ? (openBlock(), createBlock(VCard, {
                              key: 0,
                              class: "mx-auto card"
                            }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "title" }, [
                                  createVNode("span", { class: "subtitle" }, toDisplayString(unref(asideDataRef)[0][0]), 1),
                                  createVNode("span", { class: "circle1" }),
                                  createVNode("span", { class: "circle2" }),
                                  createVNode("span", { class: "circle2" })
                                ]),
                                createVNode(VList, {
                                  class: "item",
                                  color: "#152f86"
                                }, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(asideDataRef).slice(1), (list2) => {
                                      return openBlock(), createBlock(VListItem, {
                                        key: list2[1],
                                        active: unref(nameRef) === list2[0],
                                        title: list2[0],
                                        onClick: ($event) => changeName(list2)
                                      }, null, 8, ["active", "title", "onClick"]);
                                    }), 128))
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })) : createCommentVNode("", true)
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(VCol, { cols: "9" }, {
                      default: withCtx(() => [
                        createVNode(VSheet, { class: "pa-2 ma-2" }, {
                          default: withCtx(() => [
                            createVNode("div", { class: "title1" }, [
                              createVNode("div", { class: "subtitle1" }, toDisplayString(unref(nameRef)), 1),
                              createVNode("div", { class: "vertical-line" })
                            ]),
                            (openBlock(true), createBlock(Fragment, null, renderList(unref(listDataRef), (item) => {
                              return openBlock(), createBlock("div", {
                                class: "list",
                                onClick: ($event) => toDetail(item.id)
                              }, [
                                createVNode("div", { class: "left" }, toDisplayString(unref(formatDate)(item.created_at)), 1),
                                createVNode("div", { class: "right" }, toDisplayString(item.title), 1)
                              ], 8, ["onClick"]);
                            }), 256))
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VRow, { "no-gutters": "" }, {
                default: withCtx(() => [
                  createVNode(VCol, { cols: "3" }, {
                    default: withCtx(() => [
                      createVNode(VSheet, { class: "pa-2 ma-2" }, {
                        default: withCtx(() => [
                          unref(asideDataRef).length ? (openBlock(), createBlock(VCard, {
                            key: 0,
                            class: "mx-auto card"
                          }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "title" }, [
                                createVNode("span", { class: "subtitle" }, toDisplayString(unref(asideDataRef)[0][0]), 1),
                                createVNode("span", { class: "circle1" }),
                                createVNode("span", { class: "circle2" }),
                                createVNode("span", { class: "circle2" })
                              ]),
                              createVNode(VList, {
                                class: "item",
                                color: "#152f86"
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(Fragment, null, renderList(unref(asideDataRef).slice(1), (list2) => {
                                    return openBlock(), createBlock(VListItem, {
                                      key: list2[1],
                                      active: unref(nameRef) === list2[0],
                                      title: list2[0],
                                      onClick: ($event) => changeName(list2)
                                    }, null, 8, ["active", "title", "onClick"]);
                                  }), 128))
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })) : createCommentVNode("", true)
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(VCol, { cols: "9" }, {
                    default: withCtx(() => [
                      createVNode(VSheet, { class: "pa-2 ma-2" }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "title1" }, [
                            createVNode("div", { class: "subtitle1" }, toDisplayString(unref(nameRef)), 1),
                            createVNode("div", { class: "vertical-line" })
                          ]),
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(listDataRef), (item) => {
                            return openBlock(), createBlock("div", {
                              class: "list",
                              onClick: ($event) => toDetail(item.id)
                            }, [
                              createVNode("div", { class: "left" }, toDisplayString(unref(formatDate)(item.created_at)), 1),
                              createVNode("div", { class: "right" }, toDisplayString(item.title), 1)
                            ], 8, ["onClick"]);
                          }), 256))
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/list.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const list = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-d91279ff"]]);

export { list as default };
//# sourceMappingURL=list-25d4105d.mjs.map
