import { ref, withCtx, createTextVNode, toDisplayString, createVNode, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { _ as _sfc_main$1 } from './index-1aae9bf6.mjs';
import { _ as _export_sfc, V as VContainer, e as VRow, g as VCol } from '../server.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'h3';
import 'ufo';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'defu';
import 'ohash';
import '@tryghost/content-api';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const _sfc_main = {
  __name: "center",
  __ssrInlineRender: true,
  setup(__props) {
    const info = ref(
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat fuga doloribus vero! Voluptate, labore. Nonlaudantium deserunt quam molestiae, labore unde dicta ad corporis tempora esse earum quasi harum odit!Lorem ipsum dolor, sit amet consectetur adipisicing elit. Fugiat quaerat modi vitae molestias itaque impeditquam soluta rem, id autem aut inventore quis quia ea ab fugit exercitationem nisi voluptatem!Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus architecto ullam accusantiumexpedita, deserunt, officia suscipit aut exercitationem veniam placeat odio harum ducimus natus, animi nonmagni quas cumque. Molestias?Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe cumque nihil error aliquid exercitationemipsam aperiam eos, veritatis nulla cupiditate deserunt dolor atque accusantium rem. Unde atque magnamquibusdam quidem!Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam voluptatem qui magnam, sint architectoeum doloribus a! Adipisci earum eum sint porro minus, repellendus nesciunt sequi beatae iste quae quisquam.Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente placeat accusantium deserunt odio fuga,repellat reiciendis natus consequatur vel nisi sit aliquid itaque dolore quae laboriosam dicta beatae exdolorum?Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium quasi veritatis sunt accusamus, vitaequidem esse saepe eveniet officia nihil placeat delectus voluptatem dignissimos iusto cupiditate repudiandaeautem sint praesentium!"
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_sfc_main$1, null, null, _parent));
      _push(ssrRenderComponent(VContainer, { class: "container" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VRow, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(VCol, { cols: "12" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`${ssrInterpolate(info.value)}`);
                      } else {
                        return [
                          createTextVNode(toDisplayString(info.value), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(VCol, { cols: "12" }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(info.value), 1)
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VRow, null, {
                default: withCtx(() => [
                  createVNode(VCol, { cols: "12" }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(info.value), 1)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/center.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const center = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-59b2997a"]]);

export { center as default };
//# sourceMappingURL=center-03090006.mjs.map
