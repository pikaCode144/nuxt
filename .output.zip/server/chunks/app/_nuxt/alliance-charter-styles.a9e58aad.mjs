const allianceCharter_vue_vue_type_style_index_0_scoped_a79e3fb7_lang = ".container[data-v-a79e3fb7]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const allianceCharterStyles_a9e58aad = [allianceCharter_vue_vue_type_style_index_0_scoped_a79e3fb7_lang, allianceCharter_vue_vue_type_style_index_0_scoped_a79e3fb7_lang];

export { allianceCharterStyles_a9e58aad as default };
//# sourceMappingURL=alliance-charter-styles.a9e58aad.mjs.map
