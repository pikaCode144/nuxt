const policyConsultation_vue_vue_type_style_index_0_scoped_79dbdb1e_lang = ".container[data-v-79dbdb1e]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const policyConsultationStyles_1ff75cf1 = [policyConsultation_vue_vue_type_style_index_0_scoped_79dbdb1e_lang, policyConsultation_vue_vue_type_style_index_0_scoped_79dbdb1e_lang];

export { policyConsultationStyles_1ff75cf1 as default };
//# sourceMappingURL=policy-consultation-styles.1ff75cf1.mjs.map
