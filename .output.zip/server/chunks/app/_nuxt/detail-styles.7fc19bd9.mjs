const detail_vue_vue_type_style_index_0_scoped_ec157243_lang = ".detail[data-v-ec157243]{display:flex;justify-content:center;max-width:1400px}.detail .inner[data-v-ec157243]{max-width:900px;padding:40px 0}";

const detailStyles_7fc19bd9 = [detail_vue_vue_type_style_index_0_scoped_ec157243_lang, detail_vue_vue_type_style_index_0_scoped_ec157243_lang];

export { detailStyles_7fc19bd9 as default };
//# sourceMappingURL=detail-styles.7fc19bd9.mjs.map
