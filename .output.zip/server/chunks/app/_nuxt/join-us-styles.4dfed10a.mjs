const joinUs_vue_vue_type_style_index_0_scoped_df02f666_lang = ".container[data-v-df02f666]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const joinUsStyles_4dfed10a = [joinUs_vue_vue_type_style_index_0_scoped_df02f666_lang, joinUs_vue_vue_type_style_index_0_scoped_df02f666_lang];

export { joinUsStyles_4dfed10a as default };
//# sourceMappingURL=join-us-styles.4dfed10a.mjs.map
