import { ref, withAsyncContext, mergeProps, withCtx, unref, createVNode, openBlock, createBlock, createCommentVNode, useSSRContext } from 'vue';
import { _ as _export_sfc, b as useRoute, d as fetchGhostPages, V as VContainer, e as VRow, g as VCol } from '../server.mjs';
import { ssrRenderComponent } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'h3';
import 'ufo';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'defu';
import 'ohash';
import '@tryghost/content-api';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const _sfc_main = {
  __name: "shared-instruments-and-equipment",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    const { tag } = route.query;
    const info = ref([]);
    const pages = ([__temp, __restore] = withAsyncContext(() => fetchGhostPages(tag)), __temp = await __temp, __restore(), __temp);
    info.value = pages.data.value.pages;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(VContainer, mergeProps({ class: "container" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(info).length) {
              _push2(ssrRenderComponent(VRow, null, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(VCol, { cols: "12" }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(VCol, {
                        cols: "12",
                        innerHTML: unref(info)[0].html
                      }, null, 8, ["innerHTML"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              unref(info).length ? (openBlock(), createBlock(VRow, { key: 0 }, {
                default: withCtx(() => [
                  createVNode(VCol, {
                    cols: "12",
                    innerHTML: unref(info)[0].html
                  }, null, 8, ["innerHTML"])
                ]),
                _: 1
              })) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/shared-instruments-and-equipment.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const sharedInstrumentsAndEquipment = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-b21dbae2"]]);

export { sharedInstrumentsAndEquipment as default };
//# sourceMappingURL=shared-instruments-and-equipment-dfb7aebb.mjs.map
