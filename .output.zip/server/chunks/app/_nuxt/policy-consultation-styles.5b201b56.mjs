const policyConsultation_vue_vue_type_style_index_0_scoped_418fda55_lang = ".container[data-v-418fda55]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const policyConsultationStyles_5b201b56 = [policyConsultation_vue_vue_type_style_index_0_scoped_418fda55_lang, policyConsultation_vue_vue_type_style_index_0_scoped_418fda55_lang];

export { policyConsultationStyles_5b201b56 as default };
//# sourceMappingURL=policy-consultation-styles.5b201b56.mjs.map
