const openLaboratoryReservation_vue_vue_type_style_index_0_scoped_e0a4f98c_lang = ".container[data-v-e0a4f98c]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const openLaboratoryReservationStyles_eac4a81e = [openLaboratoryReservation_vue_vue_type_style_index_0_scoped_e0a4f98c_lang, openLaboratoryReservation_vue_vue_type_style_index_0_scoped_e0a4f98c_lang];

export { openLaboratoryReservationStyles_eac4a81e as default };
//# sourceMappingURL=open-laboratory-reservation-styles.eac4a81e.mjs.map
