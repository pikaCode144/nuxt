const technicalConsultation_vue_vue_type_style_index_0_scoped_053a6e78_lang = ".container[data-v-053a6e78]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const technicalConsultationStyles_cdbff1e6 = [technicalConsultation_vue_vue_type_style_index_0_scoped_053a6e78_lang, technicalConsultation_vue_vue_type_style_index_0_scoped_053a6e78_lang];

export { technicalConsultationStyles_cdbff1e6 as default };
//# sourceMappingURL=technical-consultation-styles.cdbff1e6.mjs.map
