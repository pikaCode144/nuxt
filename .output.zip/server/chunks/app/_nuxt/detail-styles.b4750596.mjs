const detail_vue_vue_type_style_index_0_scoped_51571da9_lang = ".detail[data-v-51571da9]{display:flex;justify-content:center;max-width:1400px}.detail .inner[data-v-51571da9]{max-width:900px;padding:40px 0}";

const detailStyles_b4750596 = [detail_vue_vue_type_style_index_0_scoped_51571da9_lang, detail_vue_vue_type_style_index_0_scoped_51571da9_lang];

export { detailStyles_b4750596 as default };
//# sourceMappingURL=detail-styles.b4750596.mjs.map
