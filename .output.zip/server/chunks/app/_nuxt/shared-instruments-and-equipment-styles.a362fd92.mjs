const sharedInstrumentsAndEquipment_vue_vue_type_style_index_0_scoped_b21dbae2_lang = ".container[data-v-b21dbae2]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const sharedInstrumentsAndEquipmentStyles_a362fd92 = [sharedInstrumentsAndEquipment_vue_vue_type_style_index_0_scoped_b21dbae2_lang, sharedInstrumentsAndEquipment_vue_vue_type_style_index_0_scoped_b21dbae2_lang];

export { sharedInstrumentsAndEquipmentStyles_a362fd92 as default };
//# sourceMappingURL=shared-instruments-and-equipment-styles.a362fd92.mjs.map
