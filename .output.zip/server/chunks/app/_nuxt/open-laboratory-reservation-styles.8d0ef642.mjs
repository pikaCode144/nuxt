const openLaboratoryReservation_vue_vue_type_style_index_0_scoped_ffe2ce3d_lang = ".container[data-v-ffe2ce3d]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const openLaboratoryReservationStyles_8d0ef642 = [openLaboratoryReservation_vue_vue_type_style_index_0_scoped_ffe2ce3d_lang, openLaboratoryReservation_vue_vue_type_style_index_0_scoped_ffe2ce3d_lang];

export { openLaboratoryReservationStyles_8d0ef642 as default };
//# sourceMappingURL=open-laboratory-reservation-styles.8d0ef642.mjs.map
