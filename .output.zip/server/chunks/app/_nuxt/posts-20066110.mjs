import { j as api } from '../server.mjs';

const tagPagesAPI = async (tag) => {
  return await api.pages.browse({
    filter: `tag:${tag}`,
    order: "published_at DESC"
  }).catch((err) => console.error(err));
};
const tagPostsAPI = async (tag, limit = 15) => {
  return await api.posts.browse({
    limit,
    filter: `tag:${tag}`,
    order: "published_at DESC"
  });
};

export { tagPostsAPI as a, tagPagesAPI as t };
//# sourceMappingURL=posts-20066110.mjs.map
