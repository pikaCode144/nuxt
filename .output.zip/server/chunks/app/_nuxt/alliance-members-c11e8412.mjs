import { ref, withCtx, unref, createVNode, openBlock, createBlock, createCommentVNode, useSSRContext } from 'vue';
import { _ as _export_sfc, b as useRoute, V as VContainer, d as VRow, e as VCol } from '../server.mjs';
import { ssrRenderComponent } from 'vue/server-renderer';
import { B as Banner } from './index-881f11d1.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'h3';
import 'ufo';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'defu';
import '@tryghost/content-api';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const _sfc_main = {
  __name: "alliance-members",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    route.query;
    const info = ref([]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(Banner, null, null, _parent));
      _push(ssrRenderComponent(VContainer, { class: "container" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(info).length) {
              _push2(ssrRenderComponent(VRow, null, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(VCol, { cols: "12" }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(VCol, {
                        cols: "12",
                        innerHTML: unref(info)[0].html
                      }, null, 8, ["innerHTML"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              unref(info).length ? (openBlock(), createBlock(VRow, { key: 0 }, {
                default: withCtx(() => [
                  createVNode(VCol, {
                    cols: "12",
                    innerHTML: unref(info)[0].html
                  }, null, 8, ["innerHTML"])
                ]),
                _: 1
              })) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/alliance-members.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const allianceMembers = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-accd0a23"]]);

export { allianceMembers as default };
//# sourceMappingURL=alliance-members-c11e8412.mjs.map
