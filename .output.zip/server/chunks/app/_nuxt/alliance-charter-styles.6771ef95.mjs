const allianceCharter_vue_vue_type_style_index_0_scoped_375e324c_lang = ".container[data-v-375e324c]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const allianceCharterStyles_6771ef95 = [allianceCharter_vue_vue_type_style_index_0_scoped_375e324c_lang, allianceCharter_vue_vue_type_style_index_0_scoped_375e324c_lang];

export { allianceCharterStyles_6771ef95 as default };
//# sourceMappingURL=alliance-charter-styles.6771ef95.mjs.map
