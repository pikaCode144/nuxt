const center_vue_vue_type_style_index_0_scoped_59b2997a_lang = ".container[data-v-59b2997a]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const centerStyles_6e8fe68b = [center_vue_vue_type_style_index_0_scoped_59b2997a_lang, center_vue_vue_type_style_index_0_scoped_59b2997a_lang];

export { centerStyles_6e8fe68b as default };
//# sourceMappingURL=center-styles.6e8fe68b.mjs.map
