import dayjs from 'dayjs';

const formatDate = (date) => {
  return dayjs(date).format("YYYY-MM-DD");
};

export { formatDate as f };
//# sourceMappingURL=format-7fadbdd9.mjs.map
