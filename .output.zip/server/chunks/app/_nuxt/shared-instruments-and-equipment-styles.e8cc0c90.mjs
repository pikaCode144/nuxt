const sharedInstrumentsAndEquipment_vue_vue_type_style_index_0_scoped_eaeee867_lang = ".container[data-v-eaeee867]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const sharedInstrumentsAndEquipmentStyles_e8cc0c90 = [sharedInstrumentsAndEquipment_vue_vue_type_style_index_0_scoped_eaeee867_lang, sharedInstrumentsAndEquipment_vue_vue_type_style_index_0_scoped_eaeee867_lang];

export { sharedInstrumentsAndEquipmentStyles_e8cc0c90 as default };
//# sourceMappingURL=shared-instruments-and-equipment-styles.e8cc0c90.mjs.map
