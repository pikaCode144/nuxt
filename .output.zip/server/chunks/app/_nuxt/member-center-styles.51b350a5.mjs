const memberCenter_vue_vue_type_style_index_0_scoped_f0c63c12_lang = ".container[data-v-f0c63c12]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const memberCenterStyles_51b350a5 = [memberCenter_vue_vue_type_style_index_0_scoped_f0c63c12_lang, memberCenter_vue_vue_type_style_index_0_scoped_f0c63c12_lang];

export { memberCenterStyles_51b350a5 as default };
//# sourceMappingURL=member-center-styles.51b350a5.mjs.map
