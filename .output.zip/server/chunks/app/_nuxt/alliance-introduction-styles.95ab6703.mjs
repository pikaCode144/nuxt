const allianceIntroduction_vue_vue_type_style_index_0_scoped_bbf7b4c5_lang = ".container[data-v-bbf7b4c5]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const allianceIntroductionStyles_95ab6703 = [allianceIntroduction_vue_vue_type_style_index_0_scoped_bbf7b4c5_lang, allianceIntroduction_vue_vue_type_style_index_0_scoped_bbf7b4c5_lang];

export { allianceIntroductionStyles_95ab6703 as default };
//# sourceMappingURL=alliance-introduction-styles.95ab6703.mjs.map
