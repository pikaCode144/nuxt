const allianceMembers_vue_vue_type_style_index_0_scoped_accd0a23_lang = ".container[data-v-accd0a23]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const allianceMembersStyles_eb742fe9 = [allianceMembers_vue_vue_type_style_index_0_scoped_accd0a23_lang, allianceMembers_vue_vue_type_style_index_0_scoped_accd0a23_lang];

export { allianceMembersStyles_eb742fe9 as default };
//# sourceMappingURL=alliance-members-styles.eb742fe9.mjs.map
