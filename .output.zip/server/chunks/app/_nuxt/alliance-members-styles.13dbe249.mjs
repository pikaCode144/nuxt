const allianceMembers_vue_vue_type_style_index_0_scoped_4b52ec52_lang = ".container[data-v-4b52ec52]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const allianceMembersStyles_13dbe249 = [allianceMembers_vue_vue_type_style_index_0_scoped_4b52ec52_lang, allianceMembers_vue_vue_type_style_index_0_scoped_4b52ec52_lang];

export { allianceMembersStyles_13dbe249 as default };
//# sourceMappingURL=alliance-members-styles.13dbe249.mjs.map
