const technicalConsultation_vue_vue_type_style_index_0_scoped_9bedba57_lang = ".container[data-v-9bedba57]{background-color:#f7f7f7;margin-top:20px;width:60%}";

const technicalConsultationStyles_ec7fb3d0 = [technicalConsultation_vue_vue_type_style_index_0_scoped_9bedba57_lang, technicalConsultation_vue_vue_type_style_index_0_scoped_9bedba57_lang];

export { technicalConsultationStyles_ec7fb3d0 as default };
//# sourceMappingURL=technical-consultation-styles.ec7fb3d0.mjs.map
