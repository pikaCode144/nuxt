const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.69342413.mjs').then(interopDefault),
  "pages/about.vue": () => import('./_nuxt/about-styles.3625aa95.mjs').then(interopDefault),
  "pages/alliance-charter.vue": () => import('./_nuxt/alliance-charter-styles.6771ef95.mjs').then(interopDefault),
  "pages/alliance-introduction.vue": () => import('./_nuxt/alliance-introduction-styles.95ab6703.mjs').then(interopDefault),
  "pages/alliance-members.vue": () => import('./_nuxt/alliance-members-styles.13dbe249.mjs').then(interopDefault),
  "pages/center.vue": () => import('./_nuxt/center-styles.6e8fe68b.mjs').then(interopDefault),
  "pages/detail.vue": () => import('./_nuxt/detail-styles.b4750596.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.d5eba457.mjs').then(interopDefault),
  "pages/join-us.vue": () => import('./_nuxt/join-us-styles.4dfed10a.mjs').then(interopDefault),
  "pages/list.vue": () => import('./_nuxt/list-styles.bb0fc837.mjs').then(interopDefault),
  "pages/member-center.vue": () => import('./_nuxt/member-center-styles.2311230d.mjs').then(interopDefault),
  "pages/open-laboratory-reservation.vue": () => import('./_nuxt/open-laboratory-reservation-styles.8d0ef642.mjs').then(interopDefault),
  "pages/policy-consultation.vue": () => import('./_nuxt/policy-consultation-styles.5b201b56.mjs').then(interopDefault),
  "pages/shared-instruments-and-equipment.vue": () => import('./_nuxt/shared-instruments-and-equipment-styles.a362fd92.mjs').then(interopDefault),
  "pages/technical-consultation.vue": () => import('./_nuxt/technical-consultation-styles.ec7fb3d0.mjs').then(interopDefault),
  "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.5c5be246.mjs').then(interopDefault),
  "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.6929a5d5.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
