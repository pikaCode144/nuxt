const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.4a3cac88.mjs').then(interopDefault),
  "pages/alliance-charter.vue": () => import('./_nuxt/alliance-charter-styles.a9e58aad.mjs').then(interopDefault),
  "pages/alliance-introduction.vue": () => import('./_nuxt/alliance-introduction-styles.72471179.mjs').then(interopDefault),
  "pages/center.vue": () => import('./_nuxt/center-styles.6e8fe68b.mjs').then(interopDefault),
  "pages/about.vue": () => import('./_nuxt/about-styles.6f31016f.mjs').then(interopDefault),
  "pages/alliance-members.vue": () => import('./_nuxt/alliance-members-styles.eb742fe9.mjs').then(interopDefault),
  "pages/detail.vue": () => import('./_nuxt/detail-styles.7fc19bd9.mjs').then(interopDefault),
  "pages/join-us.vue": () => import('./_nuxt/join-us-styles.14803f5b.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.3059cf7e.mjs').then(interopDefault),
  "pages/member-center.vue": () => import('./_nuxt/member-center-styles.51b350a5.mjs').then(interopDefault),
  "pages/open-laboratory-reservation.vue": () => import('./_nuxt/open-laboratory-reservation-styles.eac4a81e.mjs').then(interopDefault),
  "pages/list.vue": () => import('./_nuxt/list-styles.5859553a.mjs').then(interopDefault),
  "pages/technical-consultation.vue": () => import('./_nuxt/technical-consultation-styles.cdbff1e6.mjs').then(interopDefault),
  "pages/shared-instruments-and-equipment.vue": () => import('./_nuxt/shared-instruments-and-equipment-styles.e8cc0c90.mjs').then(interopDefault),
  "pages/policy-consultation.vue": () => import('./_nuxt/policy-consultation-styles.1ff75cf1.mjs').then(interopDefault),
  "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.5c5be246.mjs').then(interopDefault),
  "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.6929a5d5.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
