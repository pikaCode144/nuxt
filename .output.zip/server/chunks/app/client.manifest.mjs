const client_manifest = {
  "VCard.css": {
    "resourceType": "style",
    "file": "VCard.911f41ce.css",
    "src": "VCard.css"
  },
  "_VCard.50912af1.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "VCard.911f41ce.css"
    ],
    "file": "VCard.50912af1.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "VCard.911f41ce.css": {
    "file": "VCard.911f41ce.css",
    "resourceType": "style"
  },
  "_format.75b6163d.js": {
    "resourceType": "script",
    "module": true,
    "file": "format.75b6163d.js"
  },
  "_index.b31aa301.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.b31aa301.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/svg/arrow-left.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "arrow-left.ee709ac2.svg",
    "src": "assets/svg/arrow-left.svg"
  },
  "assets/svg/arrow-right.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "arrow-right.da21398e.svg",
    "src": "assets/svg/arrow-right.svg"
  },
  "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.ba70adc0.css",
    "src": "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.66379ade.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.ba70adc0.css": {
    "file": "error-404.ba70adc0.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.5dfeada7.css",
    "src": "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.87607f0e.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.5dfeada7.css": {
    "file": "error-500.5dfeada7.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.416860f6.css",
    "src": "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.416860f6.css"
    ],
    "dynamicImports": [
      "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/.pnpm/registry.npmmirror.com+@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.04ae5003.js",
    "isEntry": true,
    "src": "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.416860f6.css": {
    "file": "entry.416860f6.css",
    "resourceType": "style"
  },
  "pages/about.css": {
    "resourceType": "style",
    "file": "about.098f2be2.css",
    "src": "pages/about.css"
  },
  "pages/about.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "about.390342f7.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js",
      "_index.b31aa301.js",
      "_VCard.50912af1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/about.vue"
  },
  "about.098f2be2.css": {
    "file": "about.098f2be2.css",
    "resourceType": "style"
  },
  "pages/alliance-charter.css": {
    "resourceType": "style",
    "file": "alliance-charter.00d3d10c.css",
    "src": "pages/alliance-charter.css"
  },
  "pages/alliance-charter.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "alliance-charter.a8e7a7bb.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js",
      "_index.b31aa301.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/alliance-charter.vue"
  },
  "alliance-charter.00d3d10c.css": {
    "file": "alliance-charter.00d3d10c.css",
    "resourceType": "style"
  },
  "pages/alliance-introduction.css": {
    "resourceType": "style",
    "file": "alliance-introduction.1b2005d4.css",
    "src": "pages/alliance-introduction.css"
  },
  "pages/alliance-introduction.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "alliance-introduction.2fc4513a.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js",
      "_index.b31aa301.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/alliance-introduction.vue"
  },
  "alliance-introduction.1b2005d4.css": {
    "file": "alliance-introduction.1b2005d4.css",
    "resourceType": "style"
  },
  "pages/alliance-members.css": {
    "resourceType": "style",
    "file": "alliance-members.4413b940.css",
    "src": "pages/alliance-members.css"
  },
  "pages/alliance-members.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "alliance-members.bf13e6b4.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js",
      "_index.b31aa301.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/alliance-members.vue"
  },
  "alliance-members.4413b940.css": {
    "file": "alliance-members.4413b940.css",
    "resourceType": "style"
  },
  "pages/center.css": {
    "resourceType": "style",
    "file": "center.d73862de.css",
    "src": "pages/center.css"
  },
  "pages/center.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "center.5a084d87.js",
    "imports": [
      "_index.b31aa301.js",
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/center.vue"
  },
  "center.d73862de.css": {
    "file": "center.d73862de.css",
    "resourceType": "style"
  },
  "pages/detail.css": {
    "resourceType": "style",
    "file": "detail.4be15a3a.css",
    "src": "pages/detail.css"
  },
  "pages/detail.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "detail.382abcf5.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js",
      "_index.b31aa301.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/detail.vue"
  },
  "detail.4be15a3a.css": {
    "file": "detail.4be15a3a.css",
    "resourceType": "style"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.df13453f.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "arrow-left.ee709ac2.svg",
      "arrow-right.da21398e.svg"
    ],
    "css": [],
    "file": "index.3f98a5ea.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js",
      "_format.75b6163d.js",
      "_VCard.50912af1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.df13453f.css": {
    "file": "index.df13453f.css",
    "resourceType": "style"
  },
  "arrow-left.ee709ac2.svg": {
    "file": "arrow-left.ee709ac2.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "arrow-right.da21398e.svg": {
    "file": "arrow-right.da21398e.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/join-us.css": {
    "resourceType": "style",
    "file": "join-us.c8843cb1.css",
    "src": "pages/join-us.css"
  },
  "pages/join-us.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "join-us.c4a6886c.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js",
      "_index.b31aa301.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/join-us.vue"
  },
  "join-us.c8843cb1.css": {
    "file": "join-us.c8843cb1.css",
    "resourceType": "style"
  },
  "pages/list.css": {
    "resourceType": "style",
    "file": "list.5f8ed39a.css",
    "src": "pages/list.css"
  },
  "pages/list.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "list.da545d6b.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js",
      "_index.b31aa301.js",
      "_format.75b6163d.js",
      "_VCard.50912af1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/list.vue"
  },
  "list.5f8ed39a.css": {
    "file": "list.5f8ed39a.css",
    "resourceType": "style"
  },
  "pages/member-center.css": {
    "resourceType": "style",
    "file": "member-center.76880bdf.css",
    "src": "pages/member-center.css"
  },
  "pages/member-center.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "member-center.fb144810.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js",
      "_index.b31aa301.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/member-center.vue"
  },
  "member-center.76880bdf.css": {
    "file": "member-center.76880bdf.css",
    "resourceType": "style"
  },
  "pages/open-laboratory-reservation.css": {
    "resourceType": "style",
    "file": "open-laboratory-reservation.3e1c9a0b.css",
    "src": "pages/open-laboratory-reservation.css"
  },
  "pages/open-laboratory-reservation.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "open-laboratory-reservation.5263543a.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/open-laboratory-reservation.vue"
  },
  "open-laboratory-reservation.3e1c9a0b.css": {
    "file": "open-laboratory-reservation.3e1c9a0b.css",
    "resourceType": "style"
  },
  "pages/policy-consultation.css": {
    "resourceType": "style",
    "file": "policy-consultation.d48feb5f.css",
    "src": "pages/policy-consultation.css"
  },
  "pages/policy-consultation.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "policy-consultation.0e108d74.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/policy-consultation.vue"
  },
  "policy-consultation.d48feb5f.css": {
    "file": "policy-consultation.d48feb5f.css",
    "resourceType": "style"
  },
  "pages/shared-instruments-and-equipment.css": {
    "resourceType": "style",
    "file": "shared-instruments-and-equipment.4152371f.css",
    "src": "pages/shared-instruments-and-equipment.css"
  },
  "pages/shared-instruments-and-equipment.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "shared-instruments-and-equipment.6eb21a4b.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/shared-instruments-and-equipment.vue"
  },
  "shared-instruments-and-equipment.4152371f.css": {
    "file": "shared-instruments-and-equipment.4152371f.css",
    "resourceType": "style"
  },
  "pages/technical-consultation.css": {
    "resourceType": "style",
    "file": "technical-consultation.d59fcf04.css",
    "src": "pages/technical-consultation.css"
  },
  "pages/technical-consultation.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "technical-consultation.dde29b84.js",
    "imports": [
      "node_modules/.pnpm/registry.npmmirror.com+nuxt@3.6.5_@types+node@18.17.3_sass@1.65.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/technical-consultation.vue"
  },
  "technical-consultation.d59fcf04.css": {
    "file": "technical-consultation.d59fcf04.css",
    "resourceType": "style"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
