const _virtual__headStatic = {"headTags":"<meta charset=\"UTF-8\">\n<title>四川成都无线电官网</title>\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no\">\n<meta name=\"keywords\" content=\"四川成都无线电官网\">\n<link rel=\"shortcut icon\" href=\"favicon.ico\" type=\"image/x-icon\">\n<link rel=\"stylesheet\" type=\"text/css\" href=\"https://cdn.jsdelivr.net/npm/@mdi/font@latest/css/materialdesignicons.min.css\">","bodyTags":"","bodyTagsOpen":"","htmlAttrs":"","bodyAttrs":""};

export { _virtual__headStatic as default };
//# sourceMappingURL=_virtual_head-static.mjs.map
